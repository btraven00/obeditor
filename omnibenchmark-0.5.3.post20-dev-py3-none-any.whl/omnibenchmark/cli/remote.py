"""cli commands related to input/output files"""

import json
import sys

from pathlib import Path

import click

from omnibenchmark.core import BenchmarkExecution
from omnibenchmark.logging import logger
from omnibenchmark.cli.formatting import pretty_print_parse_error
from omnibenchmark.model.validation import BenchmarkParseError
from omnibenchmark.remote.files import checksum_files
from omnibenchmark.remote.files import list_files
from omnibenchmark.remote.files import download_files
from datetime import datetime
from difflib import unified_diff

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from omnibenchmark.remote.S3Storage import S3CompatibleStorage

from .debug import add_debug_option


def _fmt_dt(value) -> str:
    """Format a datetime or ISO string as 'YYYY-MM-DD HH:MM:SS'."""
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    return value.strftime("%Y-%m-%d %H:%M:%S")


def _make_storage(
    benchmark_path: str, require_credentials: bool = True
) -> "tuple[BenchmarkExecution, S3CompatibleStorage]":
    """Load a benchmark and return (benchmark, storage), exiting on any error."""
    from omnibenchmark.remote.service import StorageService

    try:
        service = StorageService.from_path(
            benchmark_path,
            full_model=True,
            require_credentials=require_credentials,
        )
    except BenchmarkParseError as e:
        logger.error(f"Failed to load benchmark:\n{pretty_print_parse_error(e)}")
        sys.exit(1)
    except ValueError as e:
        logger.error(click.style("[ERROR]", fg="red", bold=True) + f" {e}")
        sys.exit(1)

    return service._benchmark_model, service.storage


@click.group(name="remote")
@click.pass_context
def remote(ctx):
    """Manage remote storage."""
    ctx.ensure_object(dict)


@click.group(name="files")
@click.pass_context
def files(ctx):
    """Manage files in remote storage."""
    ctx.ensure_object(dict)


remote.add_command(files)


@click.group(name="version")
@click.pass_context
def version(ctx):
    """Manage benchmark versions."""
    ctx.ensure_object(dict)


remote.add_command(version)


@click.group(name="policy", deprecated=True)
@click.pass_context
def policy(ctx):
    """Manage storage policies. DEPRECATED: use your cloud provider's IAM tooling directly."""
    ctx.ensure_object(dict)


remote.add_command(policy)


@add_debug_option
@version.command(name="create")
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
def create_benchmark_version(benchmark: str):
    """Create a new benchmark version.

    BENCHMARK: Path to benchmark YAML file.
    """
    assert benchmark is not None

    bm, ss = _make_storage(benchmark)
    ss.set_version(bm.get_benchmark_version())

    if ss.version in ss.versions:
        logger.error(
            f"Version {ss.version} already exists. Cannot overwrite.",
        )
        sys.exit(1)
    logger.info(f"Creating benchmark version {ss.version} for bucket '{ss.benchmark}'")
    ss.create_new_version(bm)
    logger.info(f"Version {ss.version} created successfully.")


@add_debug_option
@files.command(name="list")
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
@click.option(
    "-t",
    "--type",
    help="File types. Options: all, code, inputs, outputs, logs, performance.",
    type=str,
    default="all",
)
@click.option("-s", "--stage", help="Stage to list files for.", type=str, default=None)
@click.option(
    "-m", "--module", help="Module to list files for.", type=str, default=None
)
@click.option(
    "-i", "--id", "file_id", help="File id/type to list.", type=str, default=None
)
def list_all_files(
    benchmark: str,
    type: str = "all",
    stage: str = "",
    module: str = "",
    file_id: str = "",
):
    """List all or specific files for a benchmark.

    BENCHMARK: Path to benchmark YAML file.
    """
    if file_id is not None:
        logger.error("--file_id is not implemented")
        raise click.Abort()
    if type != "all":
        logger.error("--type is not implemented")
        raise click.Abort()
    if stage is not None:
        logger.error("--stage is not implemented")
        raise click.Abort()
    if module is not None:
        logger.error("--module is not implemented")
        raise click.Abort()

    objectnames, etags = list_files(benchmark, type, stage, module, file_id)
    if len(objectnames) > 0:
        for objectname, etag in zip(objectnames, etags):
            logger.info(f"{etag} {objectname}")


@add_debug_option
@files.command(name="download")
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
@click.option(
    "-t",
    "--type",
    help="File types. Options: all, code, inputs, outputs, logs, performance.",
    type=str,
    default="all",
)
@click.option(
    "-s", "--stage", help="Stage to download files from.", type=str, default=None
)
@click.option(
    "-m", "--module", help="Module to download files from.", type=str, default=None
)
@click.option(
    "-i", "--id", "file_id", help="File id to download.", type=str, default=None
)
@click.option(
    "-o",
    "--overwrite",
    help="Overwrite existing files.",
    is_flag=True,
    default=False,
    show_default=True,
)
def download_all_files(
    benchmark: str,
    type: str = "all",
    stage: str = "",
    module: str = "",
    file_id: str = "",
    overwrite: bool = False,
):
    """Download all or specific files for a benchmark.

    BENCHMARK: Path to benchmark YAML file.
    """
    if file_id is not None:
        logger.error("--file_id is not implemented")
        raise click.Abort()
    if type != "all":
        logger.error("--type is not implemented")
        raise click.Abort()
    if stage is not None:
        logger.error("--stage is not implemented")
        raise click.Abort()
    if module is not None:
        logger.error("--module is not implemented")
        raise click.Abort()

    download_files(
        benchmark,
        type,
        stage,
        module,
        file_id,
        verbose=True,
        overwrite=overwrite,
    )


@add_debug_option
@files.command(name="checksum")
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
def checksum_all_files(benchmark: str):
    """Generate md5sums of all benchmark outputs.

    BENCHMARK: Path to benchmark YAML file.
    """

    # ARCHITECTURAL NOTE: Business Logic in CLI Layer
    # This function contains domain logic (checksum validation) that belongs in
    # a service layer. During the LinkML → Pydantic migration, CLI commands retained
    # business logic to maintain functionality while models were refactored.
    #
    # Future consideration: Extract to a ChecksumService that can be used by CLI,
    # API endpoints, or other interfaces. CLI should only handle argument parsing
    # and output formatting.
    # TODO(ben): move this logic away from CLI
    # TODO: Add CLI option to specify custom local directory (currently hardcoded to "out")
    logger.info("Checking MD5 checksums... ")
    failed_checks_filenames = checksum_files(
        benchmark=benchmark, type="all", stage="", module="", file_id="", verbose=True
    )
    if len(failed_checks_filenames) > 0:
        logger.error("Failed checksums:")
        for filename in failed_checks_filenames:
            logger.error(filename)
        raise click.Abort()
    logger.info("Done")


@add_debug_option
@policy.command(name="create")
@click.option(
    "-b",
    "--benchmark",
    "benchmark",
    help="Path to benchmark YAML file.",
    type=click.Path(exists=True),
    required=False,
)
@click.option(
    "--bucket",
    "bucket_name",
    help="S3 bucket name. If not provided, reads from benchmark YAML.",
    type=str,
    required=False,
)
def create_policy(benchmark: str, bucket_name: str):
    """Generate an S3/MinIO IAM policy for a benchmark bucket.

    This command generates a least-privilege AWS IAM policy JSON that can be used
    to create access keys in MinIO or AWS. The policy allows full S3 operations
    on the bucket but denies deletion and governance bypass.

    You can either:
    - Provide a benchmark YAML file (-b/--benchmark) to read the bucket name from storage.bucket_name
    - Provide the bucket name directly (--bucket)
    """
    from omnibenchmark.remote.S3config import benchmarker_access_token_policy

    # Get bucket name from either parameter or benchmark YAML
    if bucket_name:
        # Direct bucket name provided
        bucket = bucket_name
    elif benchmark:
        # Load from benchmark YAML
        from omnibenchmark.model.benchmark import Benchmark

        try:
            benchmark_model = Benchmark.from_yaml(Path(benchmark))
        except BenchmarkParseError as e:
            formatted_error = pretty_print_parse_error(e)
            logger.error(f"Failed to load benchmark:\n{formatted_error}")
            sys.exit(1)

        # Get storage configuration
        api = benchmark_model.get_storage_api()
        bucket = benchmark_model.get_storage_bucket_name()

        # Validate we have bucket name
        if bucket is None:
            logger.error(
                click.style("[ERROR]", fg="red", bold=True)
                + " No storage bucket configured. Set 'storage.bucket_name' in your benchmark YAML or use --bucket."
            )
            sys.exit(1)

        # Validate storage API is S3/MinIO (both use AWS IAM policies)
        if api is None:
            logger.error(
                click.style("[ERROR]", fg="red", bold=True)
                + " Storage API not configured. Set 'storage.api' to 'S3' or 'MinIO' in your benchmark YAML."
            )
            sys.exit(1)

        if api.upper() not in ("MINIO", "S3"):
            logger.error(
                click.style("[ERROR]", fg="red", bold=True)
                + f" Storage API '{api}' does not use AWS IAM policies. Only S3 and MinIO are supported."
            )
            sys.exit(1)
    else:
        # Neither provided
        logger.error(
            click.style("[ERROR]", fg="red", bold=True)
            + " Must provide either --benchmark or --bucket option."
        )
        sys.exit(1)

    # Generate and print the policy
    policy = benchmarker_access_token_policy(bucket)
    print(json.dumps(policy, indent=2))


@add_debug_option
@version.command("diff")
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
@click.option(
    "--version1",
    "-v1",
    required=True,
    type=str,
    help="Reference version.",
)
@click.option(
    "--version2",
    "-v2",
    required=True,
    type=str,
    help="Version to compare with.",
)
@click.pass_context
def diff_benchmark(ctx, benchmark: str, version1, version2):
    """Show differences between 2 benchmark versions.

    BENCHMARK: Path to benchmark YAML file.
    """
    _, ss = _make_storage(benchmark, require_credentials=False)

    available = [str(v) for v in ss.versions]
    missing = [v for v in (version1, version2) if v not in available]
    if missing:
        versions_list = ", ".join(available) if available else "(none)"
        logger.error(
            click.style("[ERROR]", fg="red", bold=True)
            + f" Version(s) not found: {', '.join(missing)}. "
            f"Available versions: {versions_list}"
        )
        sys.exit(1)

    # get objects for first version
    ss.set_version(version1)
    ss.load_objects()
    files_v1 = [
        f"{f[0]}   {f[1]['size']}   {_fmt_dt(f[1]['last_modified'])}\n"
        for f in ss.files.items()
    ]
    creation_time_v1 = ""
    if f"versions/{version1}.csv" in ss.files.keys():
        creation_time_v1 = _fmt_dt(
            ss.files[f"versions/{version1}.csv"]["last_modified"]
        )

    # get objects for second version
    ss.set_version(version2)
    ss.load_objects()
    files_v2 = [
        f"{f[0]}   {f[1]['size']}   {_fmt_dt(f[1]['last_modified'])}\n"
        for f in ss.files.items()
    ]
    creation_time_v2 = ""
    if f"versions/{version2}.csv" in ss.files.keys():
        creation_time_v2 = _fmt_dt(
            ss.files[f"versions/{version2}.csv"]["last_modified"]
        )

    logger.info(f"Differences in {benchmark} between {version1} and {version2}:")
    click.echo(
        "".join(
            list(
                unified_diff(
                    files_v1,
                    files_v2,
                    fromfile=f"version {version1}",
                    tofile=f"version {version2}",
                    fromfiledate=creation_time_v1,
                    tofiledate=creation_time_v2,
                )
            )
        )
    )


@add_debug_option
@version.command("list")
@click.argument(
    "benchmark",
    type=click.Path(exists=True),
)
@click.pass_context
def list_versions(ctx, benchmark: str):
    """List all available benchmark versions.

    BENCHMARK: Path to benchmark YAML file.
    """
    logger.info(f"Available versions of {benchmark}:")

    _, ss = _make_storage(benchmark, require_credentials=False)

    if len(ss.versions) > 0:
        if len(ss.versions) > 1:
            ss.versions.sort()
        for version in ss.versions:
            click.echo(f"{str(version):>8}")
