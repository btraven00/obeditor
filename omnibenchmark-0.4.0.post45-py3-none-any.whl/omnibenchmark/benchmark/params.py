# Params has moved to omnibenchmark.model.params
from omnibenchmark.model.params import Params  # noqa: F401

__all__ = ["Params"]
